
const Router= require('express').Router();
const student_info=require("./controler");
//post get out


Router.post('/bav',student_info.view); 
Router.post('/insert',student_info.INSERT); 
Router.post('/del',student_info.DELETE); 
Router.post('/update',student_info.UPDATE); 


module.exports=Router;