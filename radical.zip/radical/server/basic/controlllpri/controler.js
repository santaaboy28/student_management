
const connection = require("../database")

const  view=(req,res)=>{
    console.log("view");
    var view="SELECT * from `student_info`"
        connection.query(view,[],function(err,result){
        console.log("view da ")
        if(err)
        {
            res.send
            ({
                message:"err",
                status:400,
                data:err
            })
        }
        else
        {
            res.send
            ({
              message:"view",
              status:200,
              dat:result

            })
        }
    })
}
    const INSERT=(req,res)=>{
    console.log("insert");
    var INSERT="INSERT INTO student_info (`first_name`,`last_name`,`location`,`Email`,`dob`,`education`) values(?,?,?,?,?,?)"
    connection.query(INSERT,[req.body.first_name,req.body.last_name,req.body.location,req.body.Email,req.body.dob,req.body.education],function(err,result){
    
    
    
        console.log("insert da");
            if(err)
            {
                res.send
                ({
                    status:400,
                    message:'insert err',
                    data:err

                })
            }
            else
            {
                res.send
                ({

                    status:200,
                    message:'INSERT success',
                    data:result
                })
            }

    })
}
const DELETE=(req,res)=>{
var DELETE="Delete from student_info  where id=?"
connection.query(DELETE,[req.body.id],function(err,result) {
    if(err)
    {
        res.send({
            status:400,
            message:'row NOT delt',  
            data:err
        })
    }
    else
    {
        res.send({

            status:200,
            message:" ROW delete",
            data:result
        })
    }
})   
}
const UPDATE=(res,req)=>{
    console.log('update',res.body.id);
    var UPDATE="UPDATE  student_info SET `first_name`=?,`last_name`=?,location=?,`Email`=?,`dob`=?,`education`=? where id=?"
    connection.query(UPDATE,[res.body.first_name,res.body.last_name,res.body.location,res.body.Email,res.body.dob,res.body.education,res.body.id,],function(err,result){
    console.log("update aaga poran");
     if(result)
     {
        req.send({
            status:200,
            messgae:'update success',
            data:result
        })
     }
     else
     {
        req.send({
            status:400,
            message:'update err',
            data:err
        })
     }
    })
}

    module.exports={view,INSERT,DELETE,UPDATE};
