var express=require('express');
var bodyParser=require('body-parser');
var connection=require("./database");
var cors=require('cors')
connection.connect(err=>
    {
        
        if(err)
        {
        console.log("err");
        }        
        else
         {
        console.log("data base connect");
        }
    });
    var app=express();
    app.listen(1000);
    app.use(express.json())
    app.use(cors())
    app.use(bodyParser.json());
    // app.use(bodyParser.urlencoded({ extended: false }));
    
    
    app.use(require('./controlllpri/router'))