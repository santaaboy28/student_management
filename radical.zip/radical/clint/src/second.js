import React, { useEffect, useState } from 'react';
import './App.css';
import api from './api';
import {CiMedicalCross} from 'react-icons/ci'
import {ImCross} from 'react-icons/im'
import { useHistory } from 'react-router-dom';
import Modal from 'react-modal';

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor:'brown'
  },
};


function Second() {
  const [datta,setdatta]=useState([]);
  const [uname,setuname]=useState('');
  const [pass,setpass]=useState('');
  const [mail,setmail]=useState('');
  const [phone,setphone]=useState('');
  const [rev,setrev]=useState(true);
  const [data,setdata]=useState([])
  const history=useHistory();


  let subtitle;
  const [modalIsOpen, setIsOpen] =useState(false);

  function openModal() {
    setIsOpen(true);
  }

  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = '#f00';
  }

  function closeModal() {
    setIsOpen(false);
  }
  const dele=()=>{
    let id=localStorage.getItem('rrr')
    api.Dele(id)
    .then(resp=>{
      console.log(resp.data);
      if(resp.data.status==200){
        alert("deleted successfully")
        localStorage.clear()
        closeModal()
      }
    })
  }
  useEffect(()=>{
    api.Login()
    .then(resp=>{
      console.log("res",resp);
      setdata(resp.data.dat)
      console.log("dattatta",data)
    })
  },[])
  
  
  return (
    <div className='cont'>
      <div style={{}}>
      
            { rev &&
            <div style={{height:'100%',width:'95%',backgroundColor:'transparent',}}>
         				<center><samp style={{fontSize:40,color:'darkgreen'}}>STUDENT MANAGEMENT</samp></center>
        <div style={{height:'20%',color:'green',alignItems:'flex-end',width:'100%',paddingTop:'4%',marginLeft:'5%'}}>
            <div  onClick={()=>{}}>
            
            <button onClick={()=>{history.push('/sec')}} style={{width:100,height:40,backgroundColor:'green',color:'white',borderRadius:50,fontSize:20}}><CiMedicalCross style={{marginTop:1}}/>Add</button>
            </div>
          </div>

        <div style={{marginLeft:'5%',width:'95%',height:'100%',backgroundColor:'transparent',justifyContent:'space-between'}}>
            <div className='con'>
              <div className='scroll'>
                  <table style={{width:'100%',height:'100%',alignContent:'space-evenly',backgroundColor:'gray'}}>
                      <thead style={{height:'20%',width:'100%'}}>
                          <tr>
                          <th style={{width:'16%'}}>employeeName</th>
                          <th style={{width:'16%'}}>department</th>
                          <th style={{width:'16%'}}>totalleave</th>
                          <th style={{width:'16%'}}>remainingleave</th>
                          <th style={{width:'16%'}}>casualleave<th style={{width:'65%',alignItems:'center'}}>booked</th><th style={{width:'50%'}}>balance</th></th>
                          <th style={{width:'16%'}}>sickleave<th style={{width:'65%'}}>booked</th><th style={{width:'50%'}}>balance</th></th>
                          </tr>
                      </thead>
                      
                      <tbody style={{height:"80%"}}>
                      
                        {data.length > 0 && data &&
                         data.map((itm)=>(
                            <tr style={{height:'10px',width:'12.5%',textAlign:'center',backgroundColor:itm.id%2==0 ? "white":'lightgreen'}}>
                          
                          <td>{itm.id}</td>
                          <td>{itm.first_name}</td>
                          <td>{itm.last_name}</td>
                          <td>{itm.location}</td>
                          <td><td style={{width:'93.5%'}}>{itm.Email}</td><td style={{width:'95%'}}>{itm.education}</td></td>
                          <td><td style={{width:'93.5%'}}>{itm.dob}</td><td style={{width:'95%'}}>sdgi</td></td>
                          <td>
                            <button onClick={()=>{localStorage.setItem('rrr',JSON.stringify(itm));history.push('/edi')}}>Edit</button>
                          </td>
                          <td>
                          <button onClick={()=>{localStorage.setItem('rrr',itm.id);openModal()}}>Delete</button>
                          </td>
                          
                        </tr>
                          
                        
                      ))}
                       {(() => {
                      if (data && typeof data !=="undefined" && data.length > 0) {

                      }else{
                        return (<tr><td >No Records Found</td></tr>)
                      }
                    })()}
					    </tbody>
                        
                  </table>
                  <Modal
                      isOpen={modalIsOpen}
                      onAfterOpen={afterOpenModal}
                      onRequestClose={closeModal}
                      style={customStyles}
                      contentLabel="Example Modal"
                    >
                      <div style={{paddingLeft:'90%'}}><div onClick={closeModal}><ImCross /></div></div>
                      <div style={{}}><h3>surely you want to delete ?</h3></div>
                      <div style={{display:'flex',alignContent:'space-between',width:'100%',height:'50%',alignItems:'center',marginTop:'0%'}}>
                        
                        <div style={{display:'flex',flexDirection:'row',justifyContent:'space-around',height:'30%',width:'100%'}}>
                        <button style={{width:70,height:30,backgroundColor:'lightcoral',color:'black'}} onClick={dele}>OK</button>
                        <button style={{width:70,height:30,backgroundColor:'lightcoral',color:'snow'}} onClick={closeModal}>Cancel</button>
                      </div>
                      </div>
                  </Modal>
                  </div>
                  </div>
            
        
        </div>
    </div>
    }
    {/* {AddL &&
     <Viewb/>
    }
   
    {vie &&
        <Atrlve/>
    } */}
        
    </div>
    </div>
  );
}

export default Second;
