import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  useParams
} from "react-router-dom";
import './App.css';
import First from './first';
import Edit from './main';
import Second from './second';

function App() {
  return (
    <Router>
      <Switch>
        <Route exact={true} path="/">
          <Second/>
        </Route>
        <Route path="/sec" >
          <First/> 
        </Route>
        <Route path="/edi" >
          <Edit/>
        </Route>
        </Switch>
    </Router>
  );
}

export default App;
