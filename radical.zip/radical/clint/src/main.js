import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import api from './api';
import './App.css'

function Edit() {
  const [uname,setuname]=useState('');
  const [pass,setpass]=useState('');
  const [mail,setmail]=useState('');
  const [phone,setphone]=useState('');
  const [image,setimage]=useState('');
  const [data,setdata]=useState('');
  const history=useHistory()
	let ls=localStorage.getItem('rrr')
	ls=JSON.parse(ls);
	console.log("llllssss",ls);
  let id=ls.id;
  let c=()=>{
    if(!uname.trim()){
      alert('enter username');
      return 0;
    }
    if(!pass.trim()){
      alert('enter password')
      return 0;
    }
    if(!mail.trim()){
      alert('enter email');
      return 0;
    }
    if(!phone.trim()){
      alert('enter mobile number')
      return 0;
    }
    else{
		api.Leave(uname,pass,mail,phone,image,id)
		.then(resp=>{
			if(resp.status==200){
			setdata(resp.data)
			console.log(resp.data);
			localStorage.clear()
			history.replace('/')
		}
		})
    }
  };
 return (
    <div className='cont'>
      <div className='App'>
      <div ><h1>EDIT STUDENT DETAIL</h1></div>
      
      <div style={{display:'flex',flexDirection:'column',alignItems:'center',height:'10cm'}}>
      <div className='App' style={{backgroundColor:'lightblue'}}>
      <div style={{display:'flex',alignContent:'space-between',flexDirection:'column',height:'100%',justifyContent:'space-evenly',}}>
      <input className='input' placeholder='FIRST_NAME'  onChange={(txt)=>setuname(txt.target.value)} type="text"></input>
      <input className='input' placeholder='LAST_NAME' onChange={(txt)=>setpass(txt.target.value)} type="text"></input>
      <input className='input' placeholder='LOCATION' onChange={(txt)=>setmail(txt.target.value)} type="text"></input>
      <input className='input' placeholder='Email' onChange={(txt)=>setphone(txt.target.value)} type="text"></input>
      <input className='input' placeholder='dob' onChange={(txt)=>setimage(txt.target.value)} type="text"></input>
      <input className='input' placeholderColor="red" placeholder='EDUCATION'  onChange={(txt)=>setuname(txt.target.value)} type="text"></input>
      
    </div>
    <div style={{display:'flex',alignContent:'space-between',flexDirection:'column',height:'100%',justifyContent:'space-evenly',}}>
       </div>
    </div>
    <button onClick={c} style={{backgroundColor:'coral',borderRadius:20,height:30}}>register</button>
      </div>
    
      
      </div>
    </div>
  );
}
export default Edit;
