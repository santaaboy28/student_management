import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import {BrowserRouter, Link} from 'react-router-dom'
import api from './api';
import './App.css'

function First() {
  const [imagepath,setimagepath]=useState('');
  const [imagename,setimagename]=useState('');
  const [data,setdata]=useState([]);
  const [uname,setuname]=useState('');
  const [pass,setpass]=useState('');
  const [mail,setmail]=useState('');
  const [phone,setphone]=useState('');
  const [image,setimage]=useState([]);
  const [a,seta]=useState(0);
  const history=useHistory()

  let c=()=>{
    
    if(!uname.trim()){
      alert('enter username');
      return 0;
    }
    if(!pass.trim()){
      alert('enter password')
      return 0;
    }
    if(!mail.trim()){
      alert('enter email');
      return 0;
    }
    if(!phone.trim()){
      alert('enter mobile number')
      return 0;
    }
    else{
      api.Add(uname,pass,mail,phone,image)
      .then(resp=>{
        if(resp.data.status==200){
          setdata(resp.data.data);
          console.log("dattatta",data);
          history.replace('/');
        }
      })
      
      
    }
    
  };
  
 return (
    <div className='cont'>
      <div className='App'>
      <div ><h1>ADD STUDENT DETAIL</h1></div>
      
      <div style={{display:'flex',flexDirection:'column',alignItems:'center',height:'10cm'}}>
      <div className='App'>
      <div style={{display:'flex',alignContent:'space-between',flexDirection:'column',height:'100%',justifyContent:'space-evenly'}}>
      <input className='input' placeholder='first name'  onChange={(txt)=>setuname(txt.target.value)} type="text"></input>
      <input className='input' placeholder='last name' onChange={(txt)=>setpass(txt.target.value)} type="text"></input>
      <input className='input' placeholder='location' onChange={(txt)=>setmail(txt.target.value)} type="text"></input>
      <input className='input' placeholder='Email' onChange={(txt)=>setphone(txt.target.value)} type="text"></input>
      <input className='input' placeholder='dob' onChange={(txt)=>setimage(txt.target.value)} type="text"></input>
      <input className='input' placeholder='education'  onChange={(txt)=>setuname(txt.target.value)} type="text"></input>
    </div>
    
    </div>
    <button onClick={c} style={{backgroundColor:'coral',borderRadius:20,height:30}}>save</button>
      </div>
    
      
      </div>
    
    </div>
  );
    }

export default First;
