import axios from 'axios'

const Add = (uname,pass,mail,phone,image) => {
    const api = axios.create({
      baseURL: `http://localhost:1000/`,
    });
    return api
      .post("insert",
      {
        "first_name":uname,
        "last_name":mail,
        "location":phone,
        "Email":pass,
        "dob":image,
        "education":"img"
      })
      .then((response) => {
        return response;
      })
      .catch((error) => {
        return error;
      });
  };
const Login = () => {
    const api = axios.create({
      baseURL: `http://localhost:1000/`,
    });
    return api
      .post("bav")
      .then((response) => {
        return response;
      })
      .catch((error) => {
        return error;
      });
  };
  const Dele = (id) => {
    const api = axios.create({
      baseURL: `http://localhost:1000/`,
    });
    return api
      .post("del",{
          "id":id
      })
      .then((response) => {
        return response;
      })
      .catch((error) => {
        return error;
      });
  };

  const Leave = (uname,pass,mail,phone,image,id) => {
    
    const api = axios.create({
      baseURL: `http://localhost:1000/`,
    });
        return api
      .post(`update`,{
        "first_name":uname,
        "last_name":mail,
        "location":phone,
        "Email":pass,
        "dob":image,
        "education":"upd",
        "id":id
      })
      .then((response) => {
        return response;
      })
      .catch((error) => {
        return error;
    })

  };

   const empadd= (name, lastname,empid,orgemail,Department,Doj,date,age,Gender,address,employeeType,employeeStatus,employeeRole,uan,pan,aadhaar) => {
    const api = axios.create({
      baseURL: 'http://192.168.82.39:8000/',
    });
    api
      .post("empcreate",
      {
        name:name.length>0 ? name:"",
        lastname:lastname.length>0 ? lastname:"",
        empid:empid.length>0 ? empid:"",
        orgmail:orgemail.length>0 ? orgemail:"",
        department:Department.length>0 ? Department:"",
        dateofjoin:Doj.length>0 ? Doj:"",
        dob:date.length>0 ? date:"",
        age:age.length>0 ? age:"",
        gender:Gender.length>0 ? Gender:"",
        address:address.length>0 ? address:"",
        employmenttype:employeeType.length>0 ? employeeType:"",
        employementstatus:employeeStatus.length>0 ? employeeStatus:"",
        employementrole:employeeRole.length>0 ? employeeRole:"",
        uan:uan.length>0 ? uan:"",
        pan:pan.length>0 ? uan:"",
        aadhar:aadhaar.length>0 ? aadhaar:"",
      })
      .then((response) => {
        console.log("res---------->",response);
        console.log(name,lastname,empid,orgemail,Department,Doj,date,age,Gender,address,employeeType,employeeRole,employeeStatus,uan,pan,aadhaar)

        return response;
      })
      .catch((error) => {
        console.log(name,lastname,empid,orgemail,Department,Doj,date,age,Gender,address,employeeType,employeeRole,employeeStatus,uan,pan,aadhaar);

        console.log("err---------->",error);
        return error;
      });
  };
const api={
    Login,
    Add,
    empadd,
    Leave,
    Dele
}




export default api;